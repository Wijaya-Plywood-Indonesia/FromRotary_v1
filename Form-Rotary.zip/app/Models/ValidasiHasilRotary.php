<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ValidasiHasilRotary extends Model
{
    //
    protected $fillable = [
        'id_produksi',
        'role',
        'status',
    ];
}
