<?php

namespace App\Filament\Resources\SupplierKayus\Pages;

use App\Filament\Resources\SupplierKayus\SupplierKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSupplierKayu extends CreateRecord
{
    protected static string $resource = SupplierKayuResource::class;
}
