<?php

namespace App\Filament\Resources\RiwayatKayus\Pages;

use App\Filament\Resources\RiwayatKayus\RiwayatKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateRiwayatKayu extends CreateRecord
{
    protected static string $resource = RiwayatKayuResource::class;
}
