<?php

namespace App\Filament\Resources\HargaKayus\Tables;

use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class HargaKayusTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('jenisKayu.nama_kayu')
                    ->sortable(),
                TextColumn::make('panjang')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('diameter_terkecil')
                    ->label('Min')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('diameter_terbesar')
                    ->label('Max')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('grade')
                    ->label('A / B')
                    ->formatStateUsing(fn($state) => match ($state) {
                        1 => 'Grade A',
                        2 => 'Grade B',
                        default => '-',
                    })
                    ->badge()
                    ->color(fn($state) => match ($state) {
                        1 => 'success', // hijau untuk Grade A
                        2 => 'primary', // kuning untuk Grade B
                        default => 'gray',
                    })
                    ->sortable(),


                TextColumn::make('harga_beli')
                    ->label('Harga Beli')
                    ->money('IDR', locale: 'id')
                    ->sortable(),

                // TextColumn::make('created_at')
                //     ->dateTime()
                //     ->sortable()
                //     ->toggleable(isToggledHiddenByDefault: true),
                // TextColumn::make('updated_at')
                //     ->dateTime()
                //     ->sortable()
                //     ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->recordActions([

                ViewAction::make(),
                EditAction::make(),
                DeleteAction::make(),

            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}
