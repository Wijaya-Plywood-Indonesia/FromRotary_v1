<?php

namespace App\Filament\Resources\KayuPecahRotaries\Pages;

use App\Filament\Resources\KayuPecahRotaries\KayuPecahRotaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateKayuPecahRotary extends CreateRecord
{
    protected static string $resource = KayuPecahRotaryResource::class;
}
