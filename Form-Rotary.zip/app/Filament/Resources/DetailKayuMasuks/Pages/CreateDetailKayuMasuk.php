<?php

namespace App\Filament\Resources\DetailKayuMasuks\Pages;

use App\Filament\Resources\DetailKayuMasuks\DetailKayuMasukResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailKayuMasuk extends CreateRecord
{
    protected static string $resource = DetailKayuMasukResource::class;
}
