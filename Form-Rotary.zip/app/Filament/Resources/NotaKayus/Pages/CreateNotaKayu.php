<?php

namespace App\Filament\Resources\NotaKayus\Pages;

use App\Filament\Resources\NotaKayus\NotaKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNotaKayu extends CreateRecord
{
    protected static string $resource = NotaKayuResource::class;
}
