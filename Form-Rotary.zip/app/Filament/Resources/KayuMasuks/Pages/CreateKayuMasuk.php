<?php

namespace App\Filament\Resources\KayuMasuks\Pages;

use App\Filament\Resources\KayuMasuks\KayuMasukResource;
use Filament\Resources\Pages\CreateRecord;

class CreateKayuMasuk extends CreateRecord
{
    protected static string $resource = KayuMasukResource::class;
}
