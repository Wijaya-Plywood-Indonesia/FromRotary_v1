<?php

namespace App\Filament\Resources\ProduksiRotaries\Pages;

use App\Filament\Resources\ProduksiRotaries\ProduksiRotaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateProduksiRotary extends CreateRecord
{
    protected static string $resource = ProduksiRotaryResource::class;
}
