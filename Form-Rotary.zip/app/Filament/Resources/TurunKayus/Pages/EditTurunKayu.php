<?php

namespace App\Filament\Resources\TurunKayus\Pages;

use App\Filament\Resources\TurunKayus\TurunKayuResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditTurunKayu extends EditRecord
{
    protected static string $resource = TurunKayuResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}
