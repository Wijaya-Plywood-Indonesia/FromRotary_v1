<?php

namespace App\Filament\Resources\TurunKayus\Pages;

use App\Filament\Resources\TurunKayus\TurunKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateTurunKayu extends CreateRecord
{
    protected static string $resource = TurunKayuResource::class;
}
