<?php

namespace App\Filament\Resources\DetailHasilPaletRotaries\Pages;

use App\Filament\Resources\DetailHasilPaletRotaries\DetailHasilPaletRotaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailHasilPaletRotary extends CreateRecord
{
    protected static string $resource = DetailHasilPaletRotaryResource::class;
}
