<?php

namespace App\Filament\Resources\Ukurans\Pages;

use App\Filament\Resources\Ukurans\UkuranResource;
use Filament\Resources\Pages\CreateRecord;

class CreateUkuran extends CreateRecord
{
    protected static string $resource = UkuranResource::class;
}
