<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;

class LaporanProduksi extends Page
{
    /** Navigasi dan metadata halaman */
    protected static string $resource = LaporanProduksiResource::class;
}
