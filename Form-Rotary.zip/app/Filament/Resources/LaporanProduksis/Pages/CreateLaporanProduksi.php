<?php

namespace App\Filament\Resources\LaporanProduksis\Pages;

use App\Filament\Resources\LaporanProduksis\LaporanProduksiResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLaporanProduksi extends CreateRecord
{
    protected static string $resource = LaporanProduksiResource::class;
}
