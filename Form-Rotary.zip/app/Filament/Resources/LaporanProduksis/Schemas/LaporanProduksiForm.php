<?php

namespace App\Filament\Resources\LaporanProduksis\Schemas;

use Filament\Schemas\Schema;

class LaporanProduksiForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
