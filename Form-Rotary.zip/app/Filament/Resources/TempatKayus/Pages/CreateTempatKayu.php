<?php

namespace App\Filament\Resources\TempatKayus\Pages;

use App\Filament\Resources\TempatKayus\TempatKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateTempatKayu extends CreateRecord
{
    protected static string $resource = TempatKayuResource::class;
}
