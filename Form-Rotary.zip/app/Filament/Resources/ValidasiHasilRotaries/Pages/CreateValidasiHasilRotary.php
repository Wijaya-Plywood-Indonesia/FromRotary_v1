<?php

namespace App\Filament\Resources\ValidasiHasilRotaries\Pages;

use App\Filament\Resources\ValidasiHasilRotaries\ValidasiHasilRotaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateValidasiHasilRotary extends CreateRecord
{
    protected static string $resource = ValidasiHasilRotaryResource::class;
}
