<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Laporan Pembelian Kayu</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                font-size: 12px;
                margin: 25px;
                color: #000;
                background: #fff;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 8px;
            }
            th,
            td {
                border: 1px solid #444;
                padding: 5px;
                text-align: right;
            }
            th {
                background: #f5f5f5;
            }
            .group-title {
                background: #eaeaea;
                font-weight: bold;
                padding: 5px;
                margin-top: 15px;
                border: 1px solid #444;
            }
            .header-table td {
                border: none;
                padding: 4px;
            }
            .signature td {
                border: none;
                text-align: center;
                padding: 5px;
            }
        </style>
    </head>
    <body>
        <h3 style="text-align: center">NOTA KAYU</h3>

        <table class="header-table">
            <tr>
                <td>No : <?php echo e($record->no_nota); ?></td>
                <td>Seri : <?php echo e($record->kayuMasuk->seri); ?></td>
                <td><?php echo e($record->kayuMasuk->tgl_kayu_masuk); ?></td>
            </tr>
            <tr>
                <td>
                    <?php echo e($record->kayuMasuk->penggunaanSupplier->nama_supplier ?? '-'); ?>

                </td>
                <td>
                    <?php echo e($record->kayuMasuk->penggunaanKendaraanSupplier->nopol_kendaraan ?? '-'); ?>

                </td>

                <td>
                    <?php echo e($record->kayuMasuk->penggunaanDokumenKayu->dokumen_legal ?? '-'); ?>

                </td>
            </tr>
        </table>

        <?php $details = $record->kayuMasuk->detailMasukanKayu ?? collect();
        $grouped = $details->groupBy(function($item) { $kodeLahan =
        optional($item->lahan)->kode_lahan ?? '-'; $grade = $item->grade ?? 0;
        $panjang = $item->panjang ?? '-'; $jenis =
        optional($item->jenisKayu)->nama_kayu ?? '-'; return $kodeLahan . '|' .
        $grade . '|' . $panjang . '|' . $jenis; }); $grandBatang = 0; $grandM3 =
        0; $grandHarga = 0; ?> <?php $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php
        [$lahan, $grade, $ukuran, $jenis] = explode('|', $key); $gradeText =
        $grade == 1 ? 'A' : ($grade == 2 ? 'B' : '-'); $subtotalBatang =
        $items->sum('jumlah_batang'); $subtotalM3 = $items->sum('kubikasi');
        $subtotalHarga = $items->sum('total_harga'); $grandBatang +=
        $subtotalBatang; $grandM3 += $subtotalM3; $grandHarga += $subtotalHarga;
        ?>

        <div class="group-title">
            <?php echo e($lahan); ?>&nbsp;&nbsp;<?php echo e($ukuran); ?> <?php echo e($jenis); ?> (<?php echo e($gradeText); ?>)
        </div>

        <table>
            <thead>
                <tr>
                    <th style="text-align: center">D</th>
                    <th style="text-align: center">Q</th>
                    <th style="text-align: center">m³</th>
                    <th style="text-align: center">Harga</th>
                    <th style="text-align: center">Poin</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align: right"><?php echo e($detail->diameter); ?></td>
                    <td><?php echo e($detail->jumlah_batang); ?></td>
                    <td>
                        <?php echo e(number_format($detail->kubikasi ?? 0, 4, ',', '.')); ?>

                    </td>
                    <td>
                        Rp.
                        <?php echo e(number_format($detail->harga_satuan ?? 0, 0, ',', '.')); ?>

                    </td>
                    <td>
                        Rp.
                        <?php echo e(number_format($detail->total_harga ?? 0, 0, ',', '.')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th style="text-align: right">Total</th>
                    <th><?php echo e($subtotalBatang); ?></th>
                    <th><?php echo e(number_format($subtotalM3, 4, ",", ".")); ?> m³</th>
                    <th colspan="2" style="text-align: right">
                        Rp. <?php echo e(number_format($subtotalHarga, 0, ",", ".")); ?>

                    </th>
                </tr>
            </tfoot>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div style="margin-top: 20px; display: flex; justify-content: flex-end">
            <table
                style="
                    border-collapse: collapse;
                    text-align: right;
                    min-width: 300px;
                    width: 100%;
                "
            >
                <tr>
                    <td style="border: 1px solid #000">Total Kubikasi</td>
                    <td style="border: 1px solid #000">
                        <?php echo e(number_format($totalKubikasi, 4, ",", ".")); ?> m³
                    </td>
                    <td style="text-align: right; border: 1px solid #000">
                        Grand Total
                    </td>
                    <td style="border: 1px solid #000">
                        Rp. <?php echo e(number_format($grandTotal, 0, ",", ".")); ?>

                    </td>
                </tr>

                <tr>
                    <td
                        style="
                            text-align: right;
                            padding: 4px 10px;
                            border: 1px solid #000;
                        "
                    >
                        Total Batang
                    </td>
                    <td style="padding: 4px 10px; border: 1px solid #000">
                        <?php echo e(number_format($totalBatang)); ?> Batang
                    </td>
                    <td></td>
                    <td style="padding: 4px 10px; border: 1px solid #000">
                        Rp. <?php echo e(number_format($biayaTurunKayu, 0, ",", ".")); ?>

                    </td>
                </tr>

                <!-- Baris Total Akhir yang full lebar -->
                <tr>
                    <td
                        colspan="4"
                        style="
                            text-align: right;
                            font-weight: bold;
                            font-size: 18px; /* ukuran font lebih besar */
                            padding: 10px 12px;
                            border: 2px solid #000; /* tebal agar menonjol */
                            background: #f2f2f2;
                        "
                    >
                        Total Akhir: Rp.
                        <?php echo e(number_format($hargaFinal, 0, ",", ".")); ?>

                    </td>
                </tr>
            </table>
        </div>
        <br /><br /><br />
        <table class="signature" style="width: 100%">
            <tr>
                <td>Penanggung Jawab Kayu</td>
                <td>Penerima</td>
            </tr>
            <tr>
                <td style="height: 70px"></td>
                <td></td>
            </tr>
            <tr>
                <td><?php echo e($record->penanggung_jawab ?? '-'); ?></td>
                <td><?php echo e($record->penerima ?? '-'); ?></td>
            </tr>
        </table>
        <div class="footer">Dicetak pada: <?php echo e(now()->format('d-m-Y H:i')); ?></div>

        <!-- <script>
            window.print(); // otomatis buka dialog print
        </script> -->
    </body>
</html>
<?php /**PATH C:\laragon\www\Form-Rotary\resources\views/nota-kayu/print.blade.php ENDPATH**/ ?>